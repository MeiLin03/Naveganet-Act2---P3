// src/Components/Assets/Home/Home.js
import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Has iniciado sesión correctamente</h1>
    </div>
  );
}

export default Home;
